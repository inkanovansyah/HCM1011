import 'package:flutter/material.dart';

class GoalSetting extends StatefulWidget {
  const GoalSetting({super.key});

  @override
  State<GoalSetting> createState() => _goalSetting();
}

class _goalSetting extends State<GoalSetting> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
